import express from "express";
import {
  getCoins,
  updateSelectedCoins,
} from "../controllers/coinController.js";
import { authenticateToken } from "../middleware/authMiddleware.js";

const router = express.Router();

router.get("/", authenticateToken, getCoins);
router.put("/selected", authenticateToken, updateSelectedCoins);

export default router;
