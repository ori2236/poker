import pool from "../config/db.js";

export async function getCoins(req, res) {
  try {
    const [coins] = await pool.query(
      `
      SELECT
        code,
        title,
        description,
        category,
        image_mime,
        image_base64,
        sort_order
      FROM coin_catalog
      WHERE is_active = 1
      ORDER BY sort_order ASC, id ASC
      `,
    );

    const [users] = await pool.query(
      `
      SELECT selected_coin_1, selected_coin_2
      FROM users
      WHERE id = ?
      LIMIT 1
      `,
      [req.user.id],
    );

    const user = users[0];

    res.json({
      selected_coin_1: user?.selected_coin_1 || null,
      selected_coin_2: user?.selected_coin_2 || null,
      coins,
    });
  } catch (error) {
    console.error("[getCoins error]", error);
    res.status(500).json({ message: "Failed to load coins" });
  }
}

export async function updateSelectedCoins(req, res) {
  try {
    const { selected_coin_1, selected_coin_2 } = req.body;

    if (
      selected_coin_1 &&
      selected_coin_2 &&
      selected_coin_1 === selected_coin_2
    ) {
      return res.status(400).json({ message: "Choose two different coins." });
    }

    const codes = [selected_coin_1, selected_coin_2].filter(Boolean);

    if (codes.length > 0) {
      const [existing] = await pool.query(
        `
        SELECT code
        FROM coin_catalog
        WHERE code IN (?) AND is_active = 1
        `,
        [codes],
      );

      if (existing.length !== codes.length) {
        return res.status(400).json({ message: "Invalid coin selected." });
      }
    }

    await pool.query(
      `
      UPDATE users
      SET selected_coin_1 = ?, selected_coin_2 = ?
      WHERE id = ?
      `,
      [selected_coin_1 || null, selected_coin_2 || null, req.user.id],
    );

    res.json({
      message: "Selected coins updated",
      selected_coin_1: selected_coin_1 || null,
      selected_coin_2: selected_coin_2 || null,
    });
  } catch (error) {
    console.error("[updateSelectedCoins error]", error);
    res.status(500).json({ message: "Failed to update selected coins" });
  }
}
